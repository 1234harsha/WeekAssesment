﻿using Week2Assesment.Model;

namespace Week2Assesment.Repository
{
    public class CompanyRepository: ICompanyRepository
    {
        private List<Company> companies;

        public CompanyRepository()
        {
            companies = new List<Company>();
        }

        public void AddCompany(Company company)
        {
            companies.Add(company);
        }

        public void DeleteCompany(int companyId)
        {
            var companyToRemove = companies.FirstOrDefault(c => c.CompanyId == companyId);
            if (companyToRemove != null)
            {
                companies.Remove(companyToRemove);
            }
        }

        public List<Company> GetAllCompanies()
        {
            return companies;
        }

        public List<Company> GetCompaniesByCity(string city)
        {
            List<Company> companiesInCity = new List<Company>();
            foreach (var company in companies)
            {
                if (company.City == city)
                {
                    companiesInCity.Add(company);
                }
            }
            return companiesInCity;
        }

        public Company GetCompanyById(int companyId)
        {
            foreach (var company in companies)
            {
                if (company.CompanyId == companyId)
                {
                    return company;
                }
            }
            return null; 
        }
    }
    
}
