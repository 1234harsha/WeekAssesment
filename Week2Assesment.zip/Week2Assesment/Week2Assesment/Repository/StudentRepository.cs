﻿using Week2Assesment.Model;

namespace Week2Assesment.Repository
{
    public class StudentRepository : IStudentRepository
    {
        private List<Student> students;

        public StudentRepository()
        {
            students = new List<Student>();
        }

        public void AddStudent(Student student)
        {
            students.Add(student);
        }

        public void DeleteStudent(int studentId)
        {
            throw new NotImplementedException();
        }

        public List<Student> GetAllStudents()
        {
            return students;
        }

        public Student GetStudentById(int studentId)
        {
            return students.FirstOrDefault(s => s.StudentId == studentId);
        }

        public List<Student> GetStudentsByQualification(string qualification)
        {
            List<Student> studentqualification = new List<Student>();
            foreach (var student in studentqualification)
            {
                if (student.Qualification == qualification)
                {
                    studentqualification.Add(student);
                }
            }
            return studentqualification;
        }

        public List<Student> GetStudentsBySkill(string skill)
        {
            List<Student> studentskill = new List<Student>();
            foreach (var student in studentskill)
            {
                if (student.Skill == skill)
                {
                    studentskill.Add(student);
                }
            }
            return studentskill;
        }

        public void UpdateStudent(Student student)
        {
                   foreach (var updatedStudent in students)
        {
            if (updatedStudent.StudentId == student.StudentId)
            {
                    updatedStudent.Qualification = student.Qualification;
                    updatedStudent.Skill = student.Skill;
                break;
            }
        }

        }

   
    }
}
