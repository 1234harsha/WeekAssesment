﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Week2Assesment.Model;
using Week2Assesment.Repository;

namespace Week2Assesment.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IStudentRepository studentrepository;
        public StudentController(IStudentRepository studentRepository)
        {
            studentrepository = studentRepository;
        }
        [HttpPost]
        //to add students
        public IActionResult AddStudent(Student student)
        {
            studentrepository.AddStudent(student);
            return Ok("Student added successfully");
        }
        [HttpPut("UpdateStudent")]
        //to update student details
        public IActionResult UpdateStudent(Student updatedStudent)
        {
            studentrepository.UpdateStudent(updatedStudent);
            return Ok("Student updated successfully");
        }
        [HttpGet("studentById/{studentId}")]

        //to get students by id
        public IActionResult GetStudentById(int studentId)
        {
            var student = studentrepository.GetStudentById(studentId);
            if (student == null)
            {
                return NotFound("Student not found");
            }
            return Ok(student);
        }

        //delete student by id
        [HttpDelete("deletestudentbyid/{studentId}")]
        public IActionResult DeleteStudent(int studentId)
        {
            studentrepository.DeleteStudent(studentId);
            return Ok("Student deleted successfully");
        }

        //get by qualification
        [HttpGet("byqualification/{qualification}")]
        public IActionResult GetStudentsByQualification(string qualification)
        {
            var students = studentrepository.GetStudentsByQualification(qualification);
            if (students.Count == 0)
            {
                return NotFound("No students found with this qualification");
            }
            return Ok(students);
        }

        [HttpGet("byskills/{skilss}")]
        public IActionResult GetStudentsBySkills(string skills)
        {
            var students = studentrepository.GetStudentsBySkill(skills);
            if (students.Count == 0)
            {
                return NotFound("No students found with this qualification");
            }
            return Ok(students);
        }
    }
}
