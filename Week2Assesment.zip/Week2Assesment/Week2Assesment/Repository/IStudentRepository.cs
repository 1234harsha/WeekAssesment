﻿using Week2Assesment.Model;

namespace Week2Assesment.Repository
{
    public interface IStudentRepository
    {

        void AddStudent(Student student);
        Student GetStudentById(int studentId);
        List<Student> GetAllStudents();
        List<Student> GetStudentsByQualification(string qualification);
        List<Student> GetStudentsBySkill(string skill);
        void UpdateStudent(Student student);
        void DeleteStudent(int studentId);
    }
}
