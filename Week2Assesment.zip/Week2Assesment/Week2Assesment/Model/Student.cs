﻿using System.ComponentModel.DataAnnotations;

namespace Week2Assesment.Model
{
    public class Student
    {
        [Required(ErrorMessage = "StudentId is required")]
        public int StudentId { get; set; }

        [Required(ErrorMessage = "StudentName is required")]
        public string StudentName { get; set; }

        [Required(ErrorMessage = "Qualification is required")]
        public string Qualification { get; set; }

        [Required(ErrorMessage = "Skill is required")]
        public string Skill { get; set; }
    }
}
