﻿using Week2Assesment.Model;

namespace Week2Assesment.Repository
{
    public interface ICompanyRepository
    {
        void AddCompany(Company company);
        Company GetCompanyById(int companyId);
        List<Company> GetAllCompanies();
        List<Company> GetCompaniesByCity(string city);
        void DeleteCompany(int companyId);
    }
}
