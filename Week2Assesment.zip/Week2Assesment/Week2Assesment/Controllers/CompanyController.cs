﻿using Microsoft.AspNetCore.Mvc;
using Week2Assesment.Model;
using Week2Assesment.Repository;

namespace Week2Assesment.Controllers
{
    public class CompanyController : Controller
    {
        private readonly ICompanyRepository companyrepository;

        public CompanyController(ICompanyRepository companyRepository)
        {
            companyrepository = companyRepository;
        }

        [HttpPost("addCompany")]
        public IActionResult AddCompany(Company company)
        {
            companyrepository.AddCompany(company);
            return Ok("Company added successfully");
        }

        [HttpGet("GetByCompanyId/{companyId}")]
        public IActionResult GetCompanyById(int companyId)
        {
            var company = companyrepository.GetCompanyById(companyId);
            if (company == null)
            {
                return NotFound("Company not found");
            }
            return Ok(company);
        }

        [HttpDelete("deleteCompany/{companyId}")]
        public IActionResult DeleteCompany(int companyId)
        {
            companyrepository.DeleteCompany(companyId);
            return Ok("Company deleted successfully");
        }

        [HttpGet("bycity/{city}")]
        public IActionResult GetCompaniesByCity(string city)
        {
            var companies = companyrepository.GetCompaniesByCity(city);
            if (companies.Count == 0)
            {
                return NotFound("No companies found in this city");
            }
            return Ok(companies);
        }

    }

}